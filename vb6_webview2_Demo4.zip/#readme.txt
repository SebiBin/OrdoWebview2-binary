
WebView2Loader.dll can download from here:

www.vbrichclient.com/en/Downloads.htm